package org.cp;

public class DataDetail
{
	public String[] aData;
	public String[] bData;
}

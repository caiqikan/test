package org.cp;

import java.util.List;

public class Data
{
	public String[] keys;
	
	public String aPrefix;
	
	public String bPrefix;
	
	
	List<DataDetail> data;
	

}

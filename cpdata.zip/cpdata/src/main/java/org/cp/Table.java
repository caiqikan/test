package org.cp;

import java.util.List;

public class Table
{
	public String tablename;
	public String[] cellNames;
	public List<String> rows;
}
